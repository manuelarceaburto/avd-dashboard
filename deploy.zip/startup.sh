node server.js
